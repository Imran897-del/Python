// Load expenses
async function loadExpenses() {
    try {
        const categoryFilter = document.getElementById('filterCategory').value;
        const monthFilter = document.getElementById('filterMonth').value;
        
        let endpoint = '/expense/getall';

        const queryParams = [];
        
        if (categoryFilter) {
            queryParams.push(`category=${categoryFilter}`);
        }
        
        if (monthFilter) {
            queryParams.push(`month=${monthFilter}`);
        }
        
        if (queryParams.length > 0) {
            endpoint += `?${queryParams.join('&')}`;
        }
        
        const data = await makeApiRequest(endpoint);
        renderExpenses(data);
    } catch (error) {
        throw error;
    }
}

// Add new expense
async function addExpense(name, amount, category, date) {
    try {
        await makeApiRequest('/expense/add', 'POST', {
            name,
            amount,
            category,
            date
        });
    } catch (error) {
        throw error;
    }
}

// Delete expense
async function deleteExpense(id) {
    try {
        await makeApiRequest(`/expense/remove/${id}`, 'DELETE');
        await loadExpenses();
    } catch (error) {
        throw error;
    }
}

// Update expense
async function updateExpense(id, name, amount, category, date) {
    try {
        await makeApiRequest(`expense/update/${id}`, 'PUT', {
            name,
            amount,
            category,
            date
        });
        await loadExpenses();
    } catch (error) {
        throw error;
    }
}

// Mark expense as done
async function markExpenseAsDone(id) {
    try {
        await makeApiRequest(`/expenses/${id}/done`, 'PATCH');
        await loadExpenses();
    } catch (error) {
        throw error;
    }
}

// Render expenses to the table
function renderExpenses(expenses) {
    const tbody = document.getElementById('expensesTableBody');
    tbody.innerHTML = '';
    
    if (expenses.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `<td colspan="6" class="no-expenses">No expenses found</td>`;
        tbody.appendChild(row);
        return;
    }
    
    expenses.forEach(expense => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${expense.name}</td>
            <td>${formatCurrency(expense.amount)}</td>
            <td>${expense.category.charAt(0).toUpperCase() + expense.category.slice(1)}</td>
            <td>${formatDate(expense.date)}</td>
            <td>
                <span class="status ${expense.isDone ? 'done' : 'pending'}">
                    ${expense.isDone ? 'Done' : 'Pending'}
                </span>
            </td>
            <td class="actions">
                <button class="btn-edit" data-id="${expense._id}">Edit</button>
                <button class="btn-delete" data-id="${expense._id}">Delete</button>
                ${!expense.isDone ? `<button class="btn-done" data-id="${expense._id}">Mark Done</button>` : ''}
            </td>
        `;
        tbody.appendChild(row);
    });
    
    // Add event listeners to action buttons
    document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', () => openEditModal(btn.dataset.id));
    });
    
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', () => {
            if (confirm('Are you sure you want to delete this expense?')) {
                deleteExpense(btn.dataset.id);
            }
        });
    });
    
    document.querySelectorAll('.btn-done').forEach(btn => {
        btn.addEventListener('click', () => markExpenseAsDone(btn.dataset.id));
    });
}

// Open edit modal with expense data
async function openEditModal(id) {
    try {
        const expense = await makeApiRequest(`/expenses/${id}`);
        
        document.getElementById('editExpenseId').value = expense._id;
        document.getElementById('editExpenseName').value = expense.name;
        document.getElementById('editExpenseAmount').value = expense.amount;
        document.getElementById('editExpenseCategory').value = expense.category;
        document.getElementById('editExpenseDate').value = expense.date.split('T')[0];
        
        document.getElementById('editModal').style.display = 'block';
        
        // Handle form submission
        document.getElementById('editExpenseForm').onsubmit = async function(e) {
            e.preventDefault();
            const name = document.getElementById('editExpenseName').value;
            const amount = parseFloat(document.getElementById('editExpenseAmount').value);
            const category = document.getElementById('editExpenseCategory').value;
            const date = document.getElementById('editExpenseDate').value;
            
            try {
                await updateExpense(id, name, amount, category, date);
                document.getElementById('editModal').style.display = 'none';
            } catch (error) {
                alert(error.message);
            }
        };
    } catch (error) {
        alert(error.message);
    }
}