// Login function
async function login(email, password) {
    try {
        const data = await makeApiRequest("/user/login", "POST", { email, password }, false);

        if (data.token) {
            localStorage.setItem("token", data.token);  // ✅ Store token
            localStorage.setItem("user", JSON.stringify(data.user));
        } else {
            console.error("No token received from server!");
        }

        return data;
    } catch (error) {
        console.error("Login error:", error);
        throw error;
    }
}

// Register function
async function register(fullname, email, password) {
    try {
        const data = await makeApiRequest('/user/register', 'POST', { fullname, email, password }, false);
        return data;
    } catch (error) {
        throw error;
    }
}

// Logout function
async function logout() {
    try {
        await makeApiRequest('/user/logout', 'POST');
        localStorage.removeItem('token');
        localStorage.removeItem('user');
    } catch (error) {
        throw error;
    }
}