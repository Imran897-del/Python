import express, { urlencoded } from "express";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";
import cors from "cors";
import connectDB from "./database/db.js";
import userRoute from "./routes/user.route.js";
import expenseRoute from "./routes/expense.route.js";


dotenv.config({});

const app = express();
const PORT = 8000;


app.use(express.json());
app.use(urlencoded({extended:true}));
app.use(cookieParser());
const corsOptions = {
    origin: "http://127.0.0.1:5500", // Add both frontend URLs
    credentials: true,
    methods: "GET,POST,PUT,DELETE,OPTIONS",
    allowedHeaders: "Content-Type,Authorization"
};
app.use(cors(corsOptions));

app.use("/api/v1/user",userRoute);
app.use("/api/v1/expense",expenseRoute);


app.listen(PORT, ()=>{
    connectDB();
    console.log(`Server listen at port ${PORT}`);
    
})